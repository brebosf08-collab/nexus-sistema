# Nexus — Sistema de Gestão Operacional

## Setup Local

1. Instalar dependências:
```bash
pip install -r requirements.txt
```

2. Copiar e preencher o .env:
```bash
cp .env.example .env
# edite o .env com suas chaves
```

3. Rodar o banco de dados:
- Acesse https://supabase.com/dashboard
- Vá em SQL Editor
- Execute o arquivo `rls_policies.sql`

4. Iniciar o servidor:
```bash
python app.py
```

5. Acessar: http://localhost:5000

---

## Deploy no Railway

1. Faça push para o GitHub
2. Em https://railway.app → New Project → Deploy from GitHub
3. Configure as variáveis de ambiente:
   - `SECRET_KEY` → uma string longa e aleatória
   - `SUPABASE_URL` → sua URL do Supabase
   - `SUPABASE_KEY` → sua chave anon do Supabase
   - `FLASK_ENV` → production
4. O Railway detecta o Procfile e faz o deploy automaticamente

---

## Bugs corrigidos nesta versão
- ✅ SECRET_KEY sem fallback inseguro hardcoded
- ✅ Conflito de variável `supabase` no login.html (ReferenceError)
- ✅ `getSessionFromUrl` depreciado → `exchangeCodeForSession` no nova_senha.html
- ✅ CORS configurável via env (ALLOWED_ORIGIN)
- ✅ Validação de tipo de arquivo no upload de imagens
- ✅ Confirmação de senha no formulário de nova senha
- ✅ Porta configurável via variável PORT (Railway/produção)
- ✅ SQL do banco corrigido (estoque_movimentos → historico)
