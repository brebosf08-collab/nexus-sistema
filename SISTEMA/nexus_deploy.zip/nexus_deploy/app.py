import os, uuid, datetime
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, abort
from flask_cors import CORS
from werkzeug.utils import secure_filename

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from supabase_db import (
    supabase, init_db,
    registrar_empresa, autenticar_usuario, obter_empresa,
    criar_categoria, obter_categorias, deletar_categoria,
    criar_produto, obter_produtos, obter_produto, atualizar_produto, deletar_produto,
    adicionar_estoque, retirar_estoque,
    criar_vendedor, obter_vendedores, deletar_vendedor,
    criar_pedido, obter_pedidos, obter_pedido_detalhado, atualizar_status_pedido,
    obter_historico,
    criar_reuniao, obter_reunioes, atualizar_status_reuniao, deletar_reuniao,
    criar_contato, obter_contatos, deletar_contato,
    obter_dashboard,
)

BASE_DIR     = os.path.abspath(os.path.dirname(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR   = os.path.join(BASE_DIR, 'static')

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

ALLOWED_ORIGIN = os.environ.get('ALLOWED_ORIGIN', '*')
CORS(app, origins=ALLOWED_ORIGIN)

# SECRET_KEY obrigatória — sem fallback inseguro hardcoded
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
if not app.config['SECRET_KEY']:
    raise RuntimeError("SECRET_KEY não configurada. Defina a variável de ambiente SECRET_KEY.")

app.config['UPLOAD_FOLDER'] = os.path.join(STATIC_DIR, 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            if request.path.startswith('/api/'):
                return jsonify({'sucesso': False, 'mensagem': 'Sessão expirada'}), 401
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated

def get_empresa_id():
    return session.get('empresa_id')

# ── Páginas ──────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    if session.get('user_id'):
        tipo = session.get('empresa_tipo')
        if tipo == 'fornecedor': return redirect(url_for('painel_fornecedor'))
        if tipo == 'cliente':    return redirect(url_for('painel_cliente'))
        session.clear()
    return render_template('escolha.html')

@app.route('/cadastro/<tipo>')
def cadastro_page(tipo):
    if tipo not in ('fornecedor', 'cliente'): return redirect(url_for('home'))
    return render_template('cadastro.html', tipo=tipo)

@app.route('/login')
@app.route('/login/<tipo>')
def login_page(tipo=None):
    if tipo and tipo not in ('fornecedor', 'cliente'): return redirect(url_for('login_page'))
    if session.get('user_id'):
        t = session.get('empresa_tipo')
        if t == 'fornecedor': return redirect(url_for('painel_fornecedor'))
        if t == 'cliente':    return redirect(url_for('painel_cliente'))
        session.clear()
    return render_template('login.html', tipo=tipo or 'fornecedor')

@app.route('/nova_senha')
def nova_senha_page():
    return render_template('nova_senha.html')

@app.route('/fornecedor')
@login_required
def painel_fornecedor():
    if session.get('empresa_tipo') != 'fornecedor': return redirect(url_for('painel_cliente'))
    empresa = obter_empresa(get_empresa_id())
    if not empresa: session.clear(); return redirect(url_for('login_page'))
    return render_template('fornecedor.html', empresa=empresa, usuario=session.get('user_nome'))

@app.route('/cliente')
@login_required
def painel_cliente():
    if session.get('empresa_tipo') != 'cliente': return redirect(url_for('painel_fornecedor'))
    empresa = obter_empresa(get_empresa_id())
    if not empresa: session.clear(); return redirect(url_for('login_page'))
    return render_template('cliente.html', empresa=empresa, usuario=session.get('user_nome'))

@app.route('/loja/<int:forn_id>')
def vitrine_fornecedor(forn_id):
    fornecedor = obter_empresa(forn_id)
    if not fornecedor or fornecedor.get('tipo') != 'fornecedor': abort(404)
    return render_template('vitrine.html', fornecedor=fornecedor, produtos=obter_produtos(forn_id))

# ── Auth API ─────────────────────────────────────────────────────────────────

@app.route('/api/registrar', methods=['POST'])
def api_registrar():
    d = request.get_json(force=True, silent=True) or {}
    nome_empresa = (d.get('nome_empresa') or '').strip()
    tipo  = (d.get('tipo') or '').strip()
    email = (d.get('email') or '').strip()
    senha = d.get('senha') or ''
    if not nome_empresa: return jsonify({'sucesso': False, 'mensagem': 'Nome obrigatório'}), 400
    if tipo not in ('fornecedor', 'cliente'): return jsonify({'sucesso': False, 'mensagem': 'Tipo inválido'}), 400
    if not email or not senha: return jsonify({'sucesso': False, 'mensagem': 'E-mail e senha obrigatórios'}), 400
    if len(senha) < 6: return jsonify({'sucesso': False, 'mensagem': 'Senha mínimo 6 caracteres'}), 400
    r = registrar_empresa(nome_empresa, d.get('documento',''), d.get('tipo_documento','cnpj'),
                          tipo, d.get('endereco',''), d.get('telefone',''), email, senha)
    if not r.get('sucesso'): return jsonify(r), 400
    session.update({'user_id': r.get('user_id'), 'user_nome': email.split('@')[0],
                    'empresa_id': r['id'], 'empresa_tipo': tipo, 'empresa_nome': nome_empresa})
    return jsonify({'sucesso': True, 'redirect': f'/{tipo}', 'user_id': r.get('user_id'), 'empresa_id': r['id']}), 201

@app.route('/api/login_session', methods=['POST'])
def api_login_session():
    d = request.get_json(force=True, silent=True) or {}
    email = d.get('email')
    if not email: return jsonify({'sucesso': False, 'mensagem': 'Email não fornecido'}), 400
    try:
        res = supabase.table('usuarios').select('*, empresas(nome, tipo)').eq('login', email).execute()
        if not res.data: return jsonify({'sucesso': False, 'mensagem': 'Usuário não encontrado'}), 404
        u = res.data[0]
        session.update({'user_id': u['id'], 'user_nome': u['nome'], 'empresa_id': u['empresa_id'],
                        'empresa_tipo': u['empresas']['tipo'], 'empresa_nome': u['empresas']['nome']})
        redir = '/fornecedor' if u['empresas']['tipo'] == 'fornecedor' else '/cliente'
        return jsonify({'sucesso': True, 'redirect': redir})
    except Exception as e:
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500

@app.route('/api/login', methods=['POST'])
def api_login():
    d = request.get_json(force=True, silent=True) or {}
    login = (d.get('login') or '').strip()
    senha = d.get('senha') or ''
    if not login or not senha: return jsonify({'sucesso': False, 'mensagem': 'Login e senha obrigatórios'}), 400
    user = autenticar_usuario(login, senha)
    if not user: return jsonify({'sucesso': False, 'mensagem': 'Credenciais incorretas'}), 401
    session.update({'user_id': user['id'], 'user_nome': user['nome'], 'empresa_id': user['empresa_id'],
                    'empresa_tipo': user['empresa_tipo'], 'empresa_nome': user['empresa_nome']})
    return jsonify({'sucesso': True, 'redirect': '/fornecedor' if user['empresa_tipo'] == 'fornecedor' else '/cliente'})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'sucesso': True})

# ── Categorias ───────────────────────────────────────────────────────────────

@app.route('/api/categorias', methods=['GET'])
@login_required
def api_categorias(): return jsonify(obter_categorias(get_empresa_id()))

@app.route('/api/categorias', methods=['POST'])
@login_required
def api_criar_categoria():
    d = request.get_json(force=True, silent=True) or {}
    nome = (d.get('nome') or '').strip()
    if not nome: return jsonify({'sucesso': False, 'mensagem': 'Nome obrigatório'}), 400
    r = criar_categoria(get_empresa_id(), nome)
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/categorias/<int:cat_id>', methods=['DELETE'])
@login_required
def api_deletar_categoria(cat_id): return jsonify(deletar_categoria(get_empresa_id(), cat_id))

# ── Produtos ─────────────────────────────────────────────────────────────────

@app.route('/api/produtos', methods=['GET'])
@login_required
def api_produtos(): return jsonify(obter_produtos(get_empresa_id()))

@app.route('/api/produtos', methods=['POST'])
@login_required
def api_criar_produto():
    d = request.form if request.form else (request.get_json(force=True, silent=True) or {})
    nome = (d.get('nome') or '').strip()
    if not nome: return jsonify({'sucesso': False, 'mensagem': 'Nome obrigatório'}), 400
    img_fname = None
    if 'imagem' in request.files:
        img = request.files['imagem']
        if img and img.filename and allowed_file(img.filename):
            ext = img.filename.rsplit('.', 1)[1].lower()
            fname = secure_filename(f"{uuid.uuid4().hex}.{ext}")
            img.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
            img_fname = fname
    def fl(v):
        try: return float(str(v).replace(',','.'))
        except: return 0.0
    def it(v):
        try: return int(v)
        except: return 0
    r = criar_produto(get_empresa_id(), nome, d.get('sku',''), d.get('categoria_id'),
                      fl(d.get('custo',0)), fl(d.get('preco',0)),
                      it(d.get('quantidade',0)), it(d.get('minimo',0)),
                      d.get('descricao',''), img_fname)
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/produtos/<int:pid>', methods=['PUT'])
@login_required
def api_atualizar_produto(pid):
    r = atualizar_produto(get_empresa_id(), pid, request.get_json(force=True, silent=True) or {})
    return jsonify(r), (200 if r.get('sucesso') else 400)

@app.route('/api/produtos/<int:pid>', methods=['DELETE'])
@login_required
def api_deletar_produto(pid): return jsonify(deletar_produto(get_empresa_id(), pid))

@app.route('/api/produtos/<int:pid>/entrada', methods=['POST'])
@login_required
def api_entrada_estoque(pid):
    d = request.get_json(force=True, silent=True) or {}
    try: qtd = int(d.get('quantidade', 0))
    except: return jsonify({'sucesso': False, 'mensagem': 'Quantidade inválida'}), 400
    if qtd <= 0: return jsonify({'sucesso': False, 'mensagem': 'Quantidade deve ser positiva'}), 400
    r = adicionar_estoque(get_empresa_id(), pid, qtd, d.get('observacoes',''))
    return jsonify(r), (200 if r.get('sucesso') else 400)

@app.route('/api/produtos/<int:pid>/saida', methods=['POST'])
@login_required
def api_saida_estoque(pid):
    d = request.get_json(force=True, silent=True) or {}
    try: qtd = int(d.get('quantidade', 0))
    except: return jsonify({'sucesso': False, 'mensagem': 'Quantidade inválida'}), 400
    if qtd <= 0: return jsonify({'sucesso': False, 'mensagem': 'Quantidade deve ser positiva'}), 400
    r = retirar_estoque(get_empresa_id(), pid, qtd, d.get('observacoes',''))
    return jsonify(r), (200 if r.get('sucesso') else 400)

# ── Vendedores ───────────────────────────────────────────────────────────────

@app.route('/api/vendedores', methods=['GET'])
@login_required
def api_vendedores(): return jsonify(obter_vendedores(get_empresa_id()))

@app.route('/api/vendedores', methods=['POST'])
@login_required
def api_criar_vendedor():
    d = request.get_json(force=True, silent=True) or {}
    nome = (d.get('nome') or '').strip()
    if not nome: return jsonify({'sucesso': False, 'mensagem': 'Nome obrigatório'}), 400
    r = criar_vendedor(get_empresa_id(), nome, d.get('email',''), d.get('telefone',''), d.get('comissao',0))
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/vendedores/<int:vid>', methods=['DELETE'])
@login_required
def api_deletar_vendedor(vid): return jsonify(deletar_vendedor(get_empresa_id(), vid))

# ── Pedidos ──────────────────────────────────────────────────────────────────

@app.route('/api/pedidos', methods=['GET'])
@login_required
def api_listar_pedidos():
    if session.get('empresa_tipo') == 'cliente':
        return jsonify(obter_pedidos(cliente_id=get_empresa_id()))
    return jsonify(obter_pedidos(empresa_id=get_empresa_id()))

@app.route('/api/pedidos', methods=['POST'])
@login_required
def api_criar_pedido():
    d = request.get_json(force=True, silent=True) or {}
    cliente = (d.get('cliente_nome') or '').strip()
    data_p  = (d.get('data') or '').strip()
    itens   = d.get('itens') or []
    if not cliente: return jsonify({'sucesso': False, 'mensagem': 'Nome do cliente obrigatório'}), 400
    if not data_p:  return jsonify({'sucesso': False, 'mensagem': 'Data obrigatória'}), 400
    if not itens:   return jsonify({'sucesso': False, 'mensagem': 'Adicione ao menos um item'}), 400
    r = criar_pedido(get_empresa_id(), cliente, data_p, itens, d.get('vendedor_id'), d.get('observacoes',''))
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/pedidos/<int:pid>', methods=['GET'])
@login_required
def api_pedido_detalhe(pid):
    d = obter_pedido_detalhado(get_empresa_id(), pid)
    if not d: abort(404)
    return jsonify(d)

@app.route('/api/pedidos/<int:pid>/status', methods=['PUT'])
@login_required
def api_status_pedido(pid):
    d = request.get_json(force=True, silent=True) or {}
    status = (d.get('status') or '').strip()
    if not status: return jsonify({'sucesso': False, 'mensagem': 'Status obrigatório'}), 400
    return jsonify(atualizar_status_pedido(get_empresa_id(), pid, status))

# ── Demais rotas ─────────────────────────────────────────────────────────────

@app.route('/api/historico', methods=['GET'])
@login_required
def api_historico():
    return jsonify(obter_historico(get_empresa_id(),
        filtro_tipo=request.args.get('tipo') or None,
        data_inicio=request.args.get('data_inicio') or None,
        data_fim=request.args.get('data_fim') or None))

@app.route('/api/reunioes', methods=['GET'])
@login_required
def api_reunioes(): return jsonify(obter_reunioes(get_empresa_id()))

@app.route('/api/reunioes', methods=['POST'])
@login_required
def api_criar_reuniao():
    d = request.get_json(force=True, silent=True) or {}
    titulo = (d.get('titulo') or '').strip()
    if not titulo: return jsonify({'sucesso': False, 'mensagem': 'Título obrigatório'}), 400
    r = criar_reuniao(get_empresa_id(), titulo, d.get('descricao',''),
                      d.get('data_hora',''), d.get('local',''), d.get('participantes',''))
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/reunioes/<int:rid>/status', methods=['PUT'])
@login_required
def api_status_reuniao(rid):
    d = request.get_json(force=True, silent=True) or {}
    return jsonify(atualizar_status_reuniao(get_empresa_id(), rid, d.get('status','')))

@app.route('/api/reunioes/<int:rid>', methods=['DELETE'])
@login_required
def api_deletar_reuniao(rid): return jsonify(deletar_reuniao(get_empresa_id(), rid))

@app.route('/api/contatos', methods=['GET'])
@login_required
def api_contatos(): return jsonify(obter_contatos(get_empresa_id()))

@app.route('/api/contatos', methods=['POST'])
@login_required
def api_criar_contato():
    d = request.get_json(force=True, silent=True) or {}
    nome = (d.get('nome') or '').strip()
    if not nome: return jsonify({'sucesso': False, 'mensagem': 'Nome obrigatório'}), 400
    r = criar_contato(get_empresa_id(), nome, d.get('documento',''), d.get('email',''),
                      d.get('telefone',''), d.get('endereco',''), d.get('tipo','cliente'))
    return jsonify(r), (201 if r.get('sucesso') else 400)

@app.route('/api/contatos/<int:cid>', methods=['DELETE'])
@login_required
def api_deletar_contato(cid): return jsonify(deletar_contato(get_empresa_id(), cid))

@app.route('/api/dashboard', methods=['GET'])
@login_required
def api_dashboard(): return jsonify(obter_dashboard(get_empresa_id()))

@app.route('/api/catalogo/fornecedores', methods=['GET'])
@login_required
def api_catalogo_fornecedores():
    try:
        res = supabase.table('empresas').select('id, nome, email, telefone, endereco').eq('tipo', 'fornecedor').execute()
        return jsonify(res.data)
    except Exception as e:
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500

@app.route('/api/catalogo/fornecedores/<int:forn_id>/produtos', methods=['GET'])
@login_required
def api_catalogo_produtos(forn_id): return jsonify(obter_produtos(forn_id))

@app.route('/api/cliente/comprar', methods=['POST'])
@login_required
def api_cliente_comprar():
    if session.get('empresa_tipo') != 'cliente':
        return jsonify({'sucesso': False, 'mensagem': 'Apenas clientes podem comprar'}), 403
    d = request.get_json(force=True, silent=True) or {}
    forn_id = d.get('fornecedor_id')
    prod_id = d.get('produto_id')
    try: qtd = int(d.get('quantidade', 0))
    except: return jsonify({'sucesso': False, 'mensagem': 'Quantidade inválida'}), 400
    if not forn_id or not prod_id or qtd <= 0:
        return jsonify({'sucesso': False, 'mensagem': 'Dados incompletos'}), 400
    try:
        r_prod = supabase.table('produtos').select('nome, preco, quantidade').eq('id', prod_id).eq('empresa_id', forn_id).execute()
        if not r_prod.data: return jsonify({'sucesso': False, 'mensagem': 'Produto não encontrado'}), 404
        prod = r_prod.data[0]
        if prod['quantidade'] < qtd: return jsonify({'sucesso': False, 'mensagem': 'Estoque insuficiente'}), 400
        itens = [{'produto_id': prod_id, 'quantidade': qtd, 'preco': float(prod['preco']), 'subtotal': float(prod['preco']) * qtd}]
        cliente_str = f"{session.get('empresa_nome','Cliente')} ({session.get('user_nome','')})"
        r = criar_pedido(forn_id, cliente_str, datetime.date.today().strftime('%Y-%m-%d'), itens, cliente_id=get_empresa_id())
        return jsonify(r), (200 if r.get('sucesso') else 400)
    except Exception as e:
        return jsonify({'sucesso': False, 'mensagem': str(e)}), 500

# ── Start ─────────────────────────────────────────────────────────────────────

init_db()

if __name__ == '__main__':
    port  = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    app.run(debug=debug, host='0.0.0.0', port=port)
